import React,{useEffect, useState} from 'react'
import Header from './Header'
import avatar from './images/avatar.jpeg'
import {BiLike} from 'react-icons/bi'
import {BiDislike} from 'react-icons/bi'
import {HiDownload} from 'react-icons/hi'
import {PiShareFatFill} from 'react-icons/pi'

import sv1 from './images/sv1.jpeg'
import sv2 from './images/sv2.jpeg'
import sv3 from './images/sv3.jpeg'
import sv4 from './images/sv4.jpeg'
import sv5 from './images/sv5.jpeg'


function SuggestedVideos(){
  return (<>
  <div className='suggested-video'>
    <div className='suggestion-image'>
    {/* <iframe src="https://www.youtube.com/embed/jKybt-F4Jto?si=GVS9tJbmh3Kf4agf" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> */}
      <img src={sv1} ></img>
    </div>
    
    <div className='suggestion-content'>
      <div class="video-info">
            <h7 class="track-title margin-0 video-info-title font-weight-bold">Abhijit Chavda - War, Bloodshed & Treasures </h7>
            <p class="margin-0 smaller-fontsize">Ranveer Allahbadia</p>
            <p class="margin-0 smaller-fontsize">230M views</p>
      </div>
    </div>
  </div>


  <div className='suggested-video'>
    <div className='suggestion-image'>
      <img src={sv2} ></img>
    </div>
    
    <div className='suggestion-content'>
      <div class="video-info">
            <h7 class="track-title margin-0 video-info-title font-weight-bold">UNKNOWN Facts Of Shiva On Earth</h7>
            <p class="margin-0 smaller-fontsize">Ranveer Allahbadia</p>
            <p class="margin-0 smaller-fontsize">230M views</p>
      </div>
    </div>
  </div>

  <div className='suggested-video'>
    <div className='suggestion-image'>
      <img src={sv3} ></img>
    </div>
    
    <div className='suggestion-content'>
      <div class="video-info">
            <h7 class="track-title margin-0 video-info-title font-weight-bold">Deepinder Goyal - Journey From Startup To IPO</h7>
            <p class="margin-0 smaller-fontsize">Ranveer Allahbadia</p>
            <p class="margin-0 smaller-fontsize">230M views</p>
      </div>
    </div>
  </div>

  <div className='suggested-video'>
    <div className='suggestion-image'>
      <img src={sv4} ></img>
    </div>
    
    <div className='suggestion-content'>
      <div class="video-info">
            <h7 class="track-title margin-0 video-info-title font-weight-bold">Panel Discussion with MS DHONI, Tanmay Bhat</h7>
            <p class="margin-0 smaller-fontsize">Ranveer Allahbadia</p>
            <p class="margin-0 smaller-fontsize">230M views</p>
      </div>
    </div>
  </div>

  <div className='suggested-video'>
    <div className='suggestion-image'>
      <img src={sv5} ></img>
    </div>
    
    <div className='suggestion-content'>
      <div class="video-info">
            <h7 class="track-title margin-0 video-info-title font-weight-bold">Honey Singh | Biggest Comeback Ever | AJIO Presents </h7>
            <p class="margin-0 smaller-fontsize">Ranveer Allahbadia</p>
            <p class="margin-0 smaller-fontsize">20M views</p>
      </div>
    </div>
  </div>
  </>)
}

function VideoInfo() {
  return(<>
    <h5 class="white video-name ">Yuvraj Singh - Cricket, Dhoni, Life & Health | Darr Ke Aage Jeet Hai Stories On TRS हिंदी 212</h5>
    <div className='video-details'>

      <div className='channel-info white'>
        <img src={avatar} width={"30px"} height={"30px"}></img>
        <p class="margin-left bold">Ranveer Allahbadia</p>
        <button className='subscribe'>Subscribe</button>
      </div>

      <div className='video-action-buttons'>
          <button className='white buttons'><BiLike size={"1.4rem"} class="icon-bg"/>  597k | <BiDislike size={"1.4rem"} class="icon-bg"/></button>

          <button className='white share-button'>Share <PiShareFatFill class="icon-bg" size={"1.4rem"}/></button>
          
          <button className='white buttons'>Download <HiDownload class="icon-bg"size={"1.4rem"}/></button>
      </div>

      
    </div>
  </>
  )
}
  
  function Video() {
    // const [seconds, setSeconds] = useState(10);
    // const targetTime = Math.floor((new Date()).getTime()/1000 + 10);

    // // when page renders
    // useEffect(()=>{
    //   const interval = setInterval(()=>{
    //     const currentTime = Math.floor((new Date()).getTime()/1000);
    //     const remainingTime = targetTime - currentTime;

    //     if(remainingTime >= 0) setSeconds(remainingTime);
    //   },1000)
    // },[]);

    let videos = [1,2,3,4,5]
    return (
      <div>
        <Header/>
        {/* <h2>Remaining Time : {seconds}</h2> */}
        <div className='video-main-page'>
          <div className='video-frame'>
            <iframe className="iframe-video" src="https://www.youtube.com/embed/6Cb8eMxdMHo?si=Fzs6uWVXodru1Wr3?rel=0&mute=1&autoplay=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            <VideoInfo/>
          </div>
          <div className='suggestions'>
            <h4>Suggested Videos : </h4>
            {videos.map((videoId)=>{
              return(
              <SuggestedVideos/>
            )})}
          </div>
        </div>
        </div>
    )
  }
  
  export default Video
  