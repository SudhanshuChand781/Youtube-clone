// rfce - react functional component
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.js";
import React from "react";
import ytLogo from "./images/utube.png";
import Signin from "./Signin";

import { AiOutlineSearch } from "react-icons/ai";
import { IoMdNotificationsOutline } from "react-icons/io";
import { AiOutlineMenu } from "react-icons/ai";
import { BiSolidVideoPlus } from "react-icons/bi";
import { BsFillMicFill } from "react-icons/bs";
import { Link } from "react-router-dom";

function Header() {
  return (
    <div>
      <div class="header">
        <div class="header-items">
          <div class="one">
            <AiOutlineMenu class="tools" />
          </div>
          <div class="two">
            <Link to={"/"}>
              <img id="yt-logo" src={ytLogo}></img>
            </Link>
          </div>
        </div>

        <div class="header-items">
          <input placeholder="Search" class="header-search"></input>
          <button class="search-button">
            {" "}
            <AiOutlineSearch class="search-icon" />
          </button>
          <div class="header-mic">
            <BsFillMicFill class="search-icon" />
          </div>
        </div>

        <div class="header-items">
          <div class="header-tools">
            <IoMdNotificationsOutline className="tools" />
            <BiSolidVideoPlus className="tools" />
          </div>
          {/* <button class="signin-btn">Sign In</button> */}
          <button
            type="button"
            class="signin-btn"
            data-toggle="modal"
            data-target="#exampleModal"
          >
            Sign In
          </button>
        </div>

<div class="modal fade white" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog white" role="document">
    <div class="modal-content white">
      <div class="modal-header white">
        <h5 class="modal-title white" id="exampleModalLabel">Sign Up</h5>
        <button type="button" class="close white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <Signin/>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary white">Submit</button>
      </div>
    </div>
  </div>
</div>
      </div>
    </div>
  );
}

export default Header;
