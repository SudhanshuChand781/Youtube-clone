// import React from 'react'

import yuvraj from './images/yuvraj.jpeg'
import sv1 from './images/sv1.jpeg'
import sv2 from './images/sv2.jpeg'

import avatar from './images/avatar.jpeg'
import {Link} from 'react-router-dom'

// import {AiOutlineSearch} from 'react-icons/ai'
// import {BsFillMicFill} from 'react-icons/bs'
import {AiFillHome} from 'react-icons/ai'

import Header from './Header'

function VideoGrid(){
  return(
    <div class="thumbnail">
      <div class="video">
        <Link to={'/video'}>
            <img class="yt-pic" src={yuvraj}/>
        </Link>
      </div>
      <div class="video-title">
        <div>
          <img src={avatar} height={'30px'} width={'30px'} ></img>
        </div>
        <div class="video-info">
          <h4 class="track-title margin-0 ">Yuvraj Singh - Cricket, Life & Health</h4>
          <p class="margin-0 smaller-fontsize">T-series</p>
          <p class="margin-0 smaller-fontsize">230M views</p>
        </div>
      </div>

      <div class="video">
        <Link to={'/video'}>
            <img class="yt-pic" src={sv1}/>
        </Link>
      </div>
      <div class="video-title">
        <div>
          <img src={avatar} height={'30px'} width={'30px'} ></img>
        </div>
        <div class="video-info">
          <h4 class="track-title margin-0 ">Yuvraj Singh - Cricket, Life & Health</h4>
          <p class="margin-0 smaller-fontsize">T-series</p>
          <p class="margin-0 smaller-fontsize">230M views</p>
        </div>
      </div>

      <div class="video">
        <Link to={'/video'}>
            <img class="yt-pic" src={sv2}/>
        </Link>
      </div>
      <div class="video-title">
        <div>
          <img src={avatar} height={'30px'} width={'30px'} ></img>
        </div>
        <div class="video-info">
          <h4 class="track-title margin-0 ">Yuvraj Singh - Cricket, Life & Health</h4>
          <p class="margin-0 smaller-fontsize">T-series</p>
          <p class="margin-0 smaller-fontsize">230M views</p>
        </div>
      </div>
    </div>
  )
}

function Home() {
    let videos = [1,2,3,4,5,6,7,8,9,10,11,12]
    return (
      <>
        <Header/>
        {/* <div class="header">
          <div class="header-item header-class">
              <div class="one"></div>
              <div class="two">
                <Link to={'/'}><img id="yt-logo" src={ytlogo}></img></Link>
              </div>
          </div>
          
          <div class="header-search header-items">
              <input placeholder="Search" class="header-search"></input>
              <button class="search-button"> <AiOutlineSearch class='search-icon'/></button>
              <div class="header-mic"><BsFillMicFill class="search-icon"/></div>
          </div>

          <div class="header-items header-profile">
              <button class="signin-btn">Sign In</button>
          </div>
      </div> */}

      <div class="main-section">
          <div class="main-left">
            <button class="yt-side-button"> <AiFillHome class="icon-bg"/> <span class="side-button-label">Home</span></button>
            <button class="yt-side-button"> <AiFillHome class="icon-bg"/> <span class="side-button-label">Shorts</span></button>
            <button class="yt-side-button"> <AiFillHome class="icon-bg"/> <span class="side-button-label">Subscriptions</span></button>
            <hr class="white"></hr>

            <p class="white side-button-label">You</p>
          </div>

          <div class="main-right">
            {videos.map((videoId)=>{
              return(
                <VideoGrid title={'video' + videoId}/>
              )
            })}
          </div>
      </div>
        </>
    );
  }
  
  export default Home;
  

